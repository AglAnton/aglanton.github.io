<?php
  $name = $_POST['name'];
  $email = $_POST['email'];
  $number = $_POST['number'];
  $vincode = $_POST['vincode'];

  $to = 'aglanton31@ya.ru';
  $subject = 'VW-TO';
  $message = "<p><b>Имя:</b> $name</p>
  <p><b>Номер:</b> $number</p>
  <p><b>E-mail:</b> $email</p>
  <p><b>Vin код:</b> $vincode</p>";

  // echo $message;

  if ( mail ($to, $subject, $message, $headers) ) {
    echo 'Успешно!';
  } else {
    echo 'Ошибка!';
  }